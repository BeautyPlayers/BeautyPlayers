INSERT INTO `business_settings` (`id`, `type`, `value`, `lang`, `created_at`, `updated_at`) VALUES (NULL, 'toyyibpay_payment', '1', NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP); 
INSERT INTO `business_settings` (`id`, `type`, `value`, `lang`, `created_at`, `updated_at`) VALUES (NULL, 'toyyibpay_sandbox', '1', NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
INSERT INTO `business_settings` (`id`, `type`, `value`, `lang`, `created_at`, `updated_at`) VALUES (NULL, 'paytm_payment', '1', NULL, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP); 
COMMIT;
