<p>{{ $content }}</p>
<a class="btn btn-primary btn-md" href="{{ $link }}">{{ translate('Change Bid') }}</a>